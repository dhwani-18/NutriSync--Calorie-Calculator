# food_tracker/models.py

from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator
from django.utils import timezone

class Food(models.Model):
    """Model to store food items with their nutritional information"""
    
    name = models.CharField(max_length=200, unique=True)
    brand = models.CharField(max_length=100, blank=True, null=True)
    
    # Nutritional information per 100g
    calories_per_100g = models.FloatField(validators=[MinValueValidator(0)])
    protein_per_100g = models.FloatField(validators=[MinValueValidator(0)])
    carbs_per_100g = models.FloatField(validators=[MinValueValidator(0)])
    fats_per_100g = models.FloatField(validators=[MinValueValidator(0)])
    fiber_per_100g = models.FloatField(validators=[MinValueValidator(0)], default=0)
    sugar_per_100g = models.FloatField(validators=[MinValueValidator(0)], default=0)
    sodium_per_100g = models.FloatField(validators=[MinValueValidator(0)], default=0)  # in mg
    
    # Optional fields
    description = models.TextField(blank=True)
    category = models.CharField(max_length=50, blank=True)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['name']
        
    def __str__(self):
        return f"{self.name} ({self.brand})" if self.brand else self.name
    
    def calculate_nutrition(self, grams):
        """Calculate nutritional values for a given weight in grams"""
        multiplier = grams / 100
        return {
            'calories': round(self.calories_per_100g * multiplier, 1),
            'protein': round(self.protein_per_100g * multiplier, 1),
            'carbs': round(self.carbs_per_100g * multiplier, 1),
            'fats': round(self.fats_per_100g * multiplier, 1),
            'fiber': round(self.fiber_per_100g * multiplier, 1),
            'sugar': round(self.sugar_per_100g * multiplier, 1),
            'sodium': round(self.sodium_per_100g * multiplier, 1),
        }

class FoodEntry(models.Model):
    """Model to track user's food consumption"""
    
    MEAL_CHOICES = [
        ('breakfast', 'Breakfast'),
        ('lunch', 'Lunch'),
        ('dinner', 'Dinner'),
        ('snack', 'Snack'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='food_entries')
    food = models.ForeignKey(Food, on_delete=models.CASCADE, null=True, blank=True)
    
    # Quantity consumed
    quantity_grams = models.FloatField(validators=[MinValueValidator(0.1)])
    
    # When and what meal
    date_consumed = models.DateField(default=timezone.now)
    meal_type = models.CharField(max_length=20, choices=MEAL_CHOICES)
    
    # Fields for entries without associated food (from dish recognition)
    description = models.CharField(max_length=255, blank=True, null=True, 
                                  help_text="Description for entries without associated food")
    calories_value = models.FloatField(default=0, help_text="Calories for this entry")
    protein_value = models.FloatField(default=0, help_text="Protein in grams")
    carbs_value = models.FloatField(default=0, help_text="Carbohydrates in grams")
    fats_value = models.FloatField(default=0, help_text="Fats in grams")
    fiber_value = models.FloatField(default=0, help_text="Fiber in grams")
    
    # Optional notes
    notes = models.TextField(blank=True)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-date_consumed', '-created_at']
        
    def __str__(self):
        if self.food:
            return f"{self.user.username} - {self.food.name} ({self.quantity_grams}g) - {self.date_consumed}"
        else:
            return f"{self.user.username} - {self.description} - {self.date_consumed}"
    
    def save(self, *args, **kwargs):
        # If entry has associated food, calculate nutritional values
        if self.food and not (self.calories_value or self.protein_value or self.carbs_value or self.fats_value or self.fiber_value):
            self.calories_value = round((self.food.calories_per_100g * self.quantity_grams) / 100, 1)
            self.protein_value = round((self.food.protein_per_100g * self.quantity_grams) / 100, 1)
            self.carbs_value = round((self.food.carbs_per_100g * self.quantity_grams) / 100, 1)
            self.fats_value = round((self.food.fats_per_100g * self.quantity_grams) / 100, 1)
            self.fiber_value = round((self.food.fiber_per_100g * self.quantity_grams) / 100, 1)
            
            # Set description if not provided
            if not self.description:
                self.description = f"{self.food.name} ({self.quantity_grams}g)"
        
        super().save(*args, **kwargs)
    
    @property
    def calories(self):
        """Calculate calories for this entry"""
        if self.food:
            return round((self.food.calories_per_100g * self.quantity_grams) / 100, 1)
        return self.calories_value
    
    @property
    def protein(self):
        """Calculate protein for this entry"""
        if self.food:
            return round((self.food.protein_per_100g * self.quantity_grams) / 100, 1)
        return self.protein_value
    
    @property
    def carbs(self):
        """Calculate carbs for this entry"""
        if self.food:
            return round((self.food.carbs_per_100g * self.quantity_grams) / 100, 1)
        return self.carbs_value
    
    @property
    def fats(self):
        """Calculate fats for this entry"""
        if self.food:
            return round((self.food.fats_per_100g * self.quantity_grams) / 100, 1)
        return self.fats_value
    
    @property
    def nutrition_summary(self):
        """Get complete nutrition summary for this entry"""
        if self.food:
            return self.food.calculate_nutrition(self.quantity_grams)
        return {
            'calories': self.calories_value,
            'protein': self.protein_value,
            'carbs': self.carbs_value,
            'fats': self.fats_value,
            'fiber': self.fiber_value,
        }

class UserProfile(models.Model):
    """Extended user profile for health tracking"""
    
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    
    ACTIVITY_CHOICES = [
        ('sedentary', 'Sedentary (little/no exercise)'),
        ('light', 'Light (light exercise 1-3 days/week)'),
        ('moderate', 'Moderate (moderate exercise 3-5 days/week)'),
        ('active', 'Active (hard exercise 6-7 days/week)'),
        ('extra', 'Extra Active (very hard exercise, physical job)'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    
    # Basic info
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True)
    height_cm = models.FloatField(validators=[MinValueValidator(50)], null=True, blank=True)
    weight_kg = models.FloatField(validators=[MinValueValidator(20)], null=True, blank=True)
    
    # Activity and goals
    activity_level = models.CharField(max_length=20, choices=ACTIVITY_CHOICES, default='moderate')
    daily_calorie_goal = models.IntegerField(validators=[MinValueValidator(800)], null=True, blank=True)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.username}'s Profile"
    
    @property
    def age(self):
        """Calculate age from date of birth"""
        if self.date_of_birth:
            today = timezone.now().date()
            return today.year - self.date_of_birth.year - ((today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day))
        return None
    
    def calculate_bmr(self):
        """Calculate Basal Metabolic Rate using Mifflin-St Jeor Equation"""
        if not all([self.weight_kg, self.height_cm, self.age, self.gender]):
            return None
            
        # Mifflin-St Jeor Equation
        if self.gender == 'M':
            bmr = 10 * self.weight_kg + 6.25 * self.height_cm - 5 * self.age + 5
        else:  # Female or Other
            bmr = 10 * self.weight_kg + 6.25 * self.height_cm - 5 * self.age - 161
            
        return round(bmr, 0)
    
    def calculate_daily_calories(self):
        """Calculate daily calorie needs based on BMR and activity level"""
        bmr = self.calculate_bmr()
        if not bmr:
            return None
            
        activity_multipliers = {
            'sedentary': 1.2,
            'light': 1.375,
            'moderate': 1.55,
            'active': 1.725,
            'extra': 1.9,
        }
        
        multiplier = activity_multipliers.get(self.activity_level, 1.55)
        return round(bmr * multiplier, 0)