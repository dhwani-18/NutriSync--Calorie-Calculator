from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'food_tracker'

urlpatterns = [
    # Home and Dashboard
    path('', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    
    # # Authentication
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(template_name='food_tracker/login.html'), name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile, name='profile'),
    
    # Food Management
    path('foods/', views.food_list, name='food_list'),
    path('foods/search/', views.food_search, name='food_search'),
    path('foods/add/', views.add_food, name='add_food'),
    path('foods/<int:food_id>/', views.food_detail, name='food_detail'),
    
    # Food Entry Management
    path('add-entry/', views.add_food_entry, name='add_food_entry'),
    path('add-entry/<int:food_id>/', views.add_food_entry, name='add_food_entry_with_food'),
    path('entries/', views.food_entries, name='food_entries'),
    path('entries/<int:entry_id>/edit/', views.edit_food_entry, name='edit_food_entry'),
    path('entries/<int:entry_id>/delete/', views.delete_food_entry, name='delete_food_entry'),
    
    # Analytics and Reports
    path('analytics/', views.analytics, name='analytics'),
    path('daily-report/<str:date>/', views.daily_report, name='daily_report'),
    
    # API endpoints for AJAX requests
    path('api/food-search/', views.api_food_search, name='api_food_search'),
    path('api/nutrition-calc/', views.api_nutrition_calc, name='api_nutrition_calc'),
    path('api/recognize-dish/', views.api_recognize_dish, name='api_recognize_dish'),
    
    # Dish recognition
    path('recognize-dish/', views.recognize_dish_view, name='recognize_dish'),
    path('add-food-entry-direct/', views.add_food_entry_direct, name='add_food_entry_direct'),
]