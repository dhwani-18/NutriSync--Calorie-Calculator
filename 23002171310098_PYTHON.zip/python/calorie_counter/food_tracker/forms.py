# food_tracker/forms.py

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Food, FoodEntry, UserProfile

class CustomUserCreationForm(UserCreationForm):
    """Custom user creation form with Bootstrap styling"""
    
    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add Bootstrap classes to all fields
        for field_name, field in self.fields.items():
            field.widget.attrs.update({
                'class': 'form-control',
                'placeholder': f'Enter your {field.label.lower()}'
            })
        
        # Specific placeholders
        self.fields['username'].widget.attrs['placeholder'] = 'Choose a username'
        self.fields['email'].widget.attrs['placeholder'] = 'Enter your email (optional)'
        self.fields['email'].required = False
        self.fields['first_name'].widget.attrs['placeholder'] = 'First name (optional)'
        self.fields['first_name'].required = False
        self.fields['last_name'].widget.attrs['placeholder'] = 'Last name (optional)'
        self.fields['last_name'].required = False

class FoodForm(forms.ModelForm):
    """Form for adding/editing food items"""
    
    class Meta:
        model = Food
        fields = [
            'name', 'brand', 'category', 'description',
            'calories_per_100g', 'protein_per_100g', 'carbs_per_100g', 
            'fats_per_100g', 'fiber_per_100g', 'sugar_per_100g', 'sodium_per_100g'
        ]
        
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter food name'
            }),
            'brand': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter brand (optional)'
            }),
            'category': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., Fruits, Vegetables, Grains'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Additional description (optional)'
            }),
            'calories_per_100g': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '0'
            }),
            'protein_per_100g': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '0'
            }),
            'carbs_per_100g': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '0'
            }),
            'fats_per_100g': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '0'
            }),
            'fiber_per_100g': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '0'
            }),
            'sugar_per_100g': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '0'
            }),
            'sodium_per_100g': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '0'
            }),
        }
        
        labels = {
            'calories_per_100g': 'Calories (per 100g)',
            'protein_per_100g': 'Protein (g per 100g)',
            'carbs_per_100g': 'Carbohydrates (g per 100g)',
            'fats_per_100g': 'Fats (g per 100g)',
            'fiber_per_100g': 'Fiber (g per 100g)',
            'sugar_per_100g': 'Sugar (g per 100g)',
            'sodium_per_100g': 'Sodium (mg per 100g)',
        }

class FoodEntryForm(forms.ModelForm):
    """Form for adding/editing food entries"""
    
    class Meta:
        model = FoodEntry
        fields = ['food', 'quantity_grams', 'meal_type', 'date_consumed', 'notes']
        
        widgets = {
            'food': forms.Select(attrs={
                'class': 'form-control'
            }),
            'quantity_grams': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '0.1',
                'placeholder': 'Enter quantity in grams'
            }),
            'meal_type': forms.Select(attrs={
                'class': 'form-control'
            }),
            'date_consumed': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'notes': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Any additional notes (optional)'
            }),
        }
        
        labels = {
            'quantity_grams': 'Quantity (grams)',
            'meal_type': 'Meal Type',
            'date_consumed': 'Date Consumed',
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Order foods alphabetically
        self.fields['food'].queryset = Food.objects.all().order_by('name')
        
        # Set today's date as default
        from django.utils import timezone
        self.fields['date_consumed'].initial = timezone.now().date()

class UserProfileForm(forms.ModelForm):
    """Form for user profile management"""
    
    class Meta:
        model = UserProfile
        fields = [
            'date_of_birth', 'gender', 'height_cm', 'weight_kg',
            'activity_level', 'daily_calorie_goal'
        ]
        
        widgets = {
            'date_of_birth': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'gender': forms.Select(attrs={
                'class': 'form-control'
            }),
            'height_cm': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '50',
                'max': '300',
                'placeholder': 'Height in centimeters'
            }),
            'weight_kg': forms.NumberInput(attrs={
                'class': 'form-control',
                'step': '0.1',
                'min': '20',
                'max': '500',
                'placeholder': 'Weight in kilograms'
            }),
            'activity_level': forms.Select(attrs={
                'class': 'form-control'
            }),
            'daily_calorie_goal': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': '800',
                'max': '5000',
                'placeholder': 'Daily calorie goal'
            }),
        }
        
        labels = {
            'date_of_birth': 'Date of Birth',
            'height_cm': 'Height (cm)',
            'weight_kg': 'Weight (kg)',
            'activity_level': 'Activity Level',
            'daily_calorie_goal': 'Daily Calorie Goal',
        }

class QuickFoodSearchForm(forms.Form):
    """Simple form for quick food search"""
    
    search_query = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search for food...',
            'autocomplete': 'off'
        }),
        label='Search Food'
    )

class DateRangeForm(forms.Form):
    """Form for selecting date ranges in analytics"""
    
    start_date = forms.DateField(
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        }),
        label='Start Date'
    )
    
    end_date = forms.DateField(
        widget=forms.DateInput(attrs={
            'class': 'form-control',
            'type': 'date'
        }),
        label='End Date'
    )