# food_tracker/admin.py

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from .models import Food, FoodEntry, UserProfile

@admin.register(Food)
class FoodAdmin(admin.ModelAdmin):
    list_display = ['name', 'brand', 'calories_per_100g', 'protein_per_100g', 'carbs_per_100g', 'fats_per_100g', 'category']
    list_filter = ['category', 'created_at']
    search_fields = ['name', 'brand', 'description']
    list_editable = ['calories_per_100g', 'protein_per_100g', 'carbs_per_100g', 'fats_per_100g']
    ordering = ['name']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'brand', 'category', 'description')
        }),
        ('Nutritional Information (per 100g)', {
            'fields': (
                ('calories_per_100g', 'protein_per_100g'),
                ('carbs_per_100g', 'fats_per_100g'),
                ('fiber_per_100g', 'sugar_per_100g'),
                ('sodium_per_100g',)
            )
        }),
    )

@admin.register(FoodEntry)
class FoodEntryAdmin(admin.ModelAdmin):
    list_display = ('user', 'get_food_name', 'quantity_grams', 'meal_type', 'date_consumed', 'calories')
    list_filter = ['meal_type', 'date_consumed', 'food__category']
    search_fields = ['user__username', 'food__name', 'notes', 'description']
    date_hierarchy = 'date_consumed'
    ordering = ['-date_consumed', '-created_at']
    
    fieldsets = (
        ('Entry Details', {
            'fields': ('user', 'food', 'quantity_grams', 'meal_type', 'date_consumed')
        }),
        ('Additional Information', {
            'fields': ('notes',),
            'classes': ('collapse',)
        }),
    )
    
    def get_food_name(self, obj):
        if obj.food:
            return obj.food.name
        return obj.description
    get_food_name.short_description = 'Food/Dish'
    
    def calories(self, obj):
        return f"{obj.calories} kcal"
    calories.short_description = 'Calories'

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'age', 'gender', 'height_cm', 'weight_kg', 'activity_level', 'daily_calorie_goal']
    list_filter = ['gender', 'activity_level']
    search_fields = ['user__username', 'user__email']
    
    fieldsets = (
        ('User Information', {
            'fields': ('user',)
        }),
        ('Physical Information', {
            'fields': (
                ('date_of_birth', 'gender'),
                ('height_cm', 'weight_kg')
            )
        }),
        ('Goals & Activity', {
            'fields': ('activity_level', 'daily_calorie_goal')
        }),
    )
    
    def age(self, obj):
        return obj.age
    age.short_description = 'Age'

# Extend the default User admin to show profile information
class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile'

class CustomUserAdmin(UserAdmin):
    inlines = (UserProfileInline,)

# Unregister the default User admin and register our custom one
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)

# Customize admin site header and title
admin.site.site_header = "Calorie Counter Administration"
admin.site.site_title = "Calorie Counter Admin"
admin.site.index_title = "Welcome to Calorie Counter Administration"