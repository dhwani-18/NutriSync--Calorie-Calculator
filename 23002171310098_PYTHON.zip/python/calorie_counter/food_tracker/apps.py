from django.apps import AppConfig


class FoodTrackerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'food_tracker'
