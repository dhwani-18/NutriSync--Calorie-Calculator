from django import template

register = template.Library()

@register.filter
def sum_calories(food_entries):
    """
    Sums the calories from a list of food entries
    """
    try:
        return sum(entry.calories for entry in food_entries)
    except (TypeError, AttributeError):
        return 0

@register.filter
def sum_protein(food_entries):
    """
    Sums the protein from a list of food entries
    """
    try:
        return sum(entry.protein for entry in food_entries)
    except (TypeError, AttributeError):
        return 0

@register.filter
def sum_carbs(food_entries):
    """
    Sums the carbs from a list of food entries
    """
    try:
        return sum(entry.carbs for entry in food_entries)
    except (TypeError, AttributeError):
        return 0

@register.filter
def sum_fats(food_entries):
    """
    Sums the fats from a list of food entries
    """
    try:
        return sum(entry.fats for entry in food_entries)
    except (TypeError, AttributeError):
        return 0