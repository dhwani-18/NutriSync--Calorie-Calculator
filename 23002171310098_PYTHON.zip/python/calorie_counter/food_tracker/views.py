# food_tracker/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.db.models import Q, Sum
from django.utils import timezone
from datetime import datetime, date, timedelta
import json

from .models import Food, FoodEntry, UserProfile
from .forms import FoodForm, FoodEntryForm, UserProfileForm, CustomUserCreationForm

def logout_view(request):
    """Custom logout view that works with both GET and POST requests"""
    logout(request)
    messages.success(request, 'You have been successfully logged out.')
    return redirect('food_tracker:home')

def home(request):
    """Home page view"""
    context = {
        'title': 'Welcome to Calorie Counter'
    }
    return render(request, 'food_tracker/home.html', context)

@login_required
def dashboard(request):
    """Main dashboard view for logged-in users"""
    user = request.user
    today = timezone.now().date()
    
    # Get today's food entries
    today_entries = FoodEntry.objects.filter(user=user, date_consumed=today)
    
    # Calculate today's totals
    today_totals = {
        'calories': sum(entry.calories for entry in today_entries),
        'protein': sum(entry.protein for entry in today_entries),
        'carbs': sum(entry.carbs for entry in today_entries),
        'fats': sum(entry.fats for entry in today_entries),
    }
    
    # Get user profile for goals
    try:
        profile = user.userprofile
        daily_goal = profile.daily_calorie_goal or 2000
    except UserProfile.DoesNotExist:
        profile = None
        daily_goal = 2000
    
    # Calculate percentage of goal achieved
    goal_percentage = (today_totals['calories'] / daily_goal) * 100 if daily_goal > 0 else 0
    
    # Get recent entries (last 5)
    recent_entries = FoodEntry.objects.filter(user=user).order_by('-created_at')[:5]
    
    # Calculate remaining calories correctly
    remaining_calories = daily_goal - today_totals['calories']
    
    context = {
        'title': 'Dashboard',
        'today': today,
        'today_entries': today_entries,
        'today_totals': today_totals,
        'daily_goal': daily_goal,
        'goal_percentage': min(goal_percentage, 100),  # Cap at 100%
        'recent_entries': recent_entries,
        'profile': profile,
        'remaining_calories': remaining_calories,  # Add remaining calories to context
    }
    return render(request, 'food_tracker/dashboard.html', context)

def register(request):
    """User registration view"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Create user profile
            UserProfile.objects.create(user=user)
            login(request, user)
            messages.success(request, 'Registration successful! Welcome to Calorie Counter!')
            return redirect('food_tracker:dashboard')
    else:
        form = CustomUserCreationForm()
    
    context = {
        'title': 'Register',
        'form': form
    }
    return render(request, 'food_tracker/register.html', context)

@login_required
def profile(request):
    """User profile management view"""
    # Ensure user profile exists
    try:
        user_profile = request.user.userprofile
    except UserProfile.DoesNotExist:
        user_profile = UserProfile.objects.create(user=request.user)
    except Exception as e:
        # Handle any other exceptions that might occur
        messages.error(request, f'Error accessing profile: {str(e)}')
        return redirect('food_tracker:dashboard')
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=user_profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('food_tracker:profile')
    else:
        form = UserProfileForm(instance=user_profile)
    
    # Ensure form fields have proper CSS classes
    for field_name, field in form.fields.items():
        if 'class' not in field.widget.attrs:
            field.widget.attrs['class'] = 'form-control'
    
    context = {
        'title': 'Profile',
        'form': form,
        'profile': user_profile
    }
    return render(request, 'food_tracker/profile.html', context)

def food_list(request):
    """List all foods with search functionality"""
    foods = Food.objects.all().order_by('name')
    search_query = request.GET.get('search', '')
    
    if search_query:
        foods = foods.filter(
            Q(name__icontains=search_query) | 
            Q(brand__icontains=search_query) |
            Q(category__icontains=search_query)
        )
    
    context = {
        'title': 'Food Database',
        'foods': foods,
        'search_query': search_query
    }
    return render(request, 'food_tracker/food_list.html', context)

def food_search(request):
    """AJAX food search view"""
    query = request.GET.get('q', '')
    if len(query) < 2:
        return JsonResponse({'foods': []})
    
    foods = Food.objects.filter(
        Q(name__icontains=query) | 
        Q(brand__icontains=query)
    )[:10]  # Limit to 10 results
    
    foods_data = []
    for food in foods:
        foods_data.append({
            'id': food.id,
            'name': food.name,
            'brand': food.brand or '',
            'calories_per_100g': food.calories_per_100g,
            'display_name': f"{food.name} ({food.brand})" if food.brand else food.name
        })
    
    return JsonResponse({'foods': foods_data})

def add_food(request):
    """Add new food to database"""
    if request.method == 'POST':
        form = FoodForm(request.POST)
        if form.is_valid():
            food = form.save()
            messages.success(request, f'Food "{food.name}" added successfully!')
            return redirect('food_tracker:food_detail', food_id=food.id)
    else:
        form = FoodForm()
    
    context = {
        'title': 'Add New Food',
        'form': form
    }
    return render(request, 'food_tracker/add_food.html', context)

def food_detail(request, food_id):
    """Display detailed information about a food item"""
    food = get_object_or_404(Food, id=food_id)
    
    context = {
        'title': f'{food.name} - Details',
        'food': food
    }
    return render(request, 'food_tracker/food_detail.html', context)

@login_required
def add_food_entry(request, food_id=None):
    """Add a food entry to user's log"""
    selected_food = None
    if food_id:
        selected_food = get_object_or_404(Food, id=food_id)
    
    if request.method == 'POST':
        form = FoodEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.user = request.user
            entry.save()
            messages.success(request, 'Food entry added successfully!')
            return redirect('food_tracker:dashboard')
    else:
        initial_data = {}
        if selected_food:
            initial_data['food'] = selected_food
            initial_data['date_consumed'] = timezone.now().date()
        form = FoodEntryForm(initial=initial_data)
    
    context = {
        'title': 'Add Food Entry',
        'form': form,
        'selected_food': selected_food
    }
    return render(request, 'food_tracker/add_food_entry.html', context)

@login_required
def food_entries(request):
    """List user's food entries"""
    entries = FoodEntry.objects.filter(user=request.user).order_by('-date_consumed', '-created_at')
    
    # Optional date filtering
    date_filter = request.GET.get('date')
    if date_filter:
        try:
            filter_date = datetime.strptime(date_filter, '%Y-%m-%d').date()
            entries = entries.filter(date_consumed=filter_date)
        except ValueError:
            pass
    
    context = {
        'title': 'My Food Entries',
        'entries': entries,
        'date_filter': date_filter
    }
    return render(request, 'food_tracker/food_enteries.html', context)

@login_required
def edit_food_entry(request, entry_id):
    """Edit an existing food entry"""
    entry = get_object_or_404(FoodEntry, id=entry_id, user=request.user)
    
    if request.method == 'POST':
        form = FoodEntryForm(request.POST, instance=entry)
        if form.is_valid():
            form.save()
            messages.success(request, 'Food entry updated successfully!')
            return redirect('food_tracker:food_entries')
    else:
        form = FoodEntryForm(instance=entry)
    
    context = {
        'title': 'Edit Food Entry',
        'form': form,
        'entry': entry
    }
    return render(request, 'food_tracker/edit_food_entry.html', context)

@login_required
def delete_food_entry(request, entry_id):
    """Delete a food entry"""
    entry = get_object_or_404(FoodEntry, id=entry_id, user=request.user)
    
    if request.method == 'POST':
        entry.delete()
        messages.success(request, 'Food entry deleted successfully!')
        return redirect('food_tracker:food_entries')
    
    context = {
        'title': 'Delete Food Entry',
        'entry': entry
    }
    return render(request, 'food_tracker/delete_food_entry.html', context)

@login_required
def analytics(request):
    """Analytics and reports view"""
    user = request.user
    
    # Get date range (default to last 7 days)
    end_date = timezone.now().date()
    start_date = end_date - timedelta(days=6)  # 7 days total including today
    
    # Get entries for the date range
    entries = FoodEntry.objects.filter(
        user=user,
        date_consumed__range=[start_date, end_date]
    )
    
    # Calculate daily totals
    daily_data = {}
    
    # Initialize all days in range with zero values
    current_date = start_date
    while current_date <= end_date:
        date_str = current_date.strftime('%Y-%m-%d')
        daily_data[date_str] = {
            'date': current_date,
            'calories': 0,
            'protein': 0,
            'carbs': 0,
            'fats': 0
        }
        current_date += timedelta(days=1)
    
    # Add actual entry data
    for entry in entries:
        date_str = entry.date_consumed.strftime('%Y-%m-%d')
        if date_str in daily_data:
            daily_data[date_str]['calories'] += entry.calories
            daily_data[date_str]['protein'] += entry.protein
            daily_data[date_str]['carbs'] += entry.carbs
            daily_data[date_str]['fats'] += entry.fats
    
    # Convert to list and sort by date
    daily_data_list = list(daily_data.values())
    daily_data_list.sort(key=lambda x: x['date'])
    
    # Calculate averages
    total_days = len([day for day in daily_data_list if day['calories'] > 0])
    total_calories = sum(day['calories'] for day in daily_data_list)
    total_protein = sum(day['protein'] for day in daily_data_list)
    
    avg_calories = total_calories / total_days if total_days > 0 else 0
    avg_protein = total_protein / total_days if total_days > 0 else 0
    
    context = {
        'title': 'Analytics',
        'daily_data': daily_data_list,
        'start_date': start_date,
        'end_date': end_date,
        'total_days': total_days,
        'avg_calories': avg_calories,
        'avg_protein': avg_protein,
    }
    return render(request, 'food_tracker/analytics.html', context)

@login_required
def daily_report(request, date):
    """Detailed report for a specific date"""
    try:
        report_date = datetime.strptime(date, '%Y-%m-%d').date()
    except ValueError:
        messages.error(request, 'Invalid date format')
        return redirect('food_tracker:dashboard')
    
    entries = FoodEntry.objects.filter(
        user=request.user,
        date_consumed=report_date
    ).order_by('meal_type', 'created_at')
    
    # Group entries by meal type
    meals = {}
    total_nutrition = {'calories': 0, 'protein': 0, 'carbs': 0, 'fats': 0}
    
    for entry in entries:
        meal = entry.meal_type
        if meal not in meals:
            meals[meal] = {'entries': [], 'totals': {'calories': 0, 'protein': 0, 'carbs': 0, 'fats': 0}}
        
        meals[meal]['entries'].append(entry)
        meals[meal]['totals']['calories'] += entry.calories
        meals[meal]['totals']['protein'] += entry.protein
        meals[meal]['totals']['carbs'] += entry.carbs
        meals[meal]['totals']['fats'] += entry.fats
        
        total_nutrition['calories'] += entry.calories
        total_nutrition['protein'] += entry.protein
        total_nutrition['carbs'] += entry.carbs
        total_nutrition['fats'] += entry.fats
    
    context = {
        'title': f'Daily Report - {report_date.strftime("%B %d, %Y")}',
        'report_date': report_date,
        'meals': meals,
        'total_nutrition': total_nutrition,
        'entries': entries
    }
    return render(request, 'food_tracker/daily_report.html', context)

# API Views for AJAX requests
def api_food_search(request):
    """API endpoint for food search"""
    return food_search(request)  # Reuse the existing function

@login_required
def api_nutrition_calc(request):
    """API endpoint to calculate nutrition for given food and quantity"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            food_id = data.get('food_id')
            quantity = float(data.get('quantity', 0))
            
            food = get_object_or_404(Food, id=food_id)
            nutrition = food.calculate_nutrition(quantity)
            
            return JsonResponse({
                'success': True,
                'nutrition': nutrition
            })
        except (ValueError, TypeError, json.JSONDecodeError):
            return JsonResponse({
                'success': False,
                'error': 'Invalid data provided'
            })
    
    return JsonResponse({'success': False, 'error': 'POST method required'})

@login_required
def recognize_dish_view(request):
    """View for recognizing dishes by name"""
    from .dish_recognition import recognize_dish
    
    if request.method == 'GET':
        return render(request, 'food_tracker/recognize_dish.html', {
            'title': 'Recognize Dish'
        })
    
    elif request.method == 'POST':
        dish_name = request.POST.get('dish_name', '')
        
        if not dish_name:
            messages.error(request, 'Please enter a dish name')
            return redirect('food_tracker:recognize_dish')
        
        # Call the dish recognition function
        result = recognize_dish(dish_name)
        
        if 'error' in result:
            messages.error(request, result['error'])
            return redirect('food_tracker:recognize_dish')
        
        # Create context with the result
        context = {
            'title': f'Results for {dish_name}',
            'dish_name': dish_name,
            'result': result,
            'form': FoodForm(initial=result)  # Pre-fill form with API results
        }
        
        return render(request, 'food_tracker/recognize_dish_results.html', context)

@login_required
def api_recognize_dish(request):
    """API endpoint for dish recognition"""
    from .dish_recognition import recognize_dish
    
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            dish_name = data.get('dish_name', '')
            
            if not dish_name:
                return JsonResponse({
                    'success': False,
                    'error': 'Dish name is required'
                })
            
            # Call the dish recognition function
            result = recognize_dish(dish_name)
            
            if 'error' in result:
                return JsonResponse({
                    'success': False,
                    'error': result['error']
                })
            
            return JsonResponse({
                'success': True,
                'result': result
            })
            
        except (ValueError, TypeError, json.JSONDecodeError):
            return JsonResponse({
                'success': False,
                'error': 'Invalid data provided'
            })
    
    return JsonResponse({'success': False, 'error': 'POST method required'})

@login_required
def add_food_entry_direct(request):
    """Add a food entry directly from recognized dish without saving to food database"""
    if request.method == 'POST':
        # Get form data
        food_name = request.POST.get('food_name', '')
        quantity = float(request.POST.get('quantity', 0))
        meal_type = request.POST.get('meal_type', 'snack')
        date_str = request.POST.get('date', '')
        notes = request.POST.get('notes', '')
        
        # Get nutritional values
        calories_per_100g = float(request.POST.get('calories_per_100g', 0))
        protein_per_100g = float(request.POST.get('protein_per_100g', 0))
        carbs_per_100g = float(request.POST.get('carbs_per_100g', 0))
        fats_per_100g = float(request.POST.get('fats_per_100g', 0))
        fiber_per_100g = float(request.POST.get('fiber_per_100g', 0))
        
        # Calculate actual nutritional values based on quantity
        factor = quantity / 100.0
        calories = calories_per_100g * factor
        protein = protein_per_100g * factor
        carbs = carbs_per_100g * factor
        fats = fats_per_100g * factor
        fiber = fiber_per_100g * factor
        
        # Parse date
        try:
            entry_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            entry_date = timezone.now().date()
        
        # Create a food description
        food_description = f"{food_name} ({quantity}g)"
        
        # Create the food entry
        entry = FoodEntry(
            user=request.user,
            food=None,  # No associated food in database
            quantity_grams=quantity,
            meal_type=meal_type,
            date_consumed=entry_date,
            calories_value=calories,
            protein_value=protein,
            carbs_value=carbs,
            fats_value=fats,
            fiber_value=fiber,
            description=food_description,
            notes=notes
        )
        entry.save()
        
        messages.success(request, f'Added {food_name} to your {meal_type} entries')
        return redirect('food_tracker:dashboard')
    
    # If not POST, redirect to dashboard
    return redirect('food_tracker:dashboard')