# food_tracker/dish_recognition.py

import requests
import json
import os
from django.conf import settings

# This module provides functionality to recognize dishes and get nutritional information
# from dish names using external APIs

# You would need to sign up for an API key from a food recognition service
# Examples include: Edamam, Spoonacular, Nutritionix, etc.

# For this example, we'll use Edamam API
# Sign up at https://developer.edamam.com/food-database-api

EDAMAM_APP_ID = os.environ.get('EDAMAM_APP_ID', '')
EDAMAM_APP_KEY = os.environ.get('EDAMAM_APP_KEY', '')

def recognize_dish(dish_name):
    """
    Recognize a dish by name and return nutritional information
    
    Args:
        dish_name (str): The name of the dish to recognize
        
    Returns:
        dict: Nutritional information for the dish or None if not found
    """
    if not EDAMAM_APP_ID or not EDAMAM_APP_KEY:
        return {
            'error': 'API credentials not configured. Please set EDAMAM_APP_ID and EDAMAM_APP_KEY environment variables.'
        }
    
    try:
        # Edamam Food Database API endpoint
        url = 'https://api.edamam.com/api/food-database/v2/parser'
        
        # Parameters for the API request
        params = {
            'app_id': EDAMAM_APP_ID,
            'app_key': EDAMAM_APP_KEY,
            'ingr': dish_name,
            'nutrition-type': 'cooking'
        }
        
        # Make the API request
        response = requests.get(url, params=params)
        response.raise_for_status()  # Raise exception for HTTP errors
        
        # Parse the response
        data = response.json()
        
        # Check if we got any results
        if not data.get('hints') or len(data['hints']) == 0:
            return {
                'error': f'No nutritional information found for "{dish_name}"'
            }
        
        # Get the first (most relevant) result
        first_result = data['hints'][0]
        food = first_result['food']
        
        # Extract nutritional information
        nutrients = food.get('nutrients', {})
        
        # Format the response
        result = {
            'name': food.get('label', dish_name),
            'category': food.get('category', 'Unknown'),
            'calories_per_100g': round(nutrients.get('ENERC_KCAL', 0), 1),
            'protein_per_100g': round(nutrients.get('PROCNT', 0), 1),
            'carbs_per_100g': round(nutrients.get('CHOCDF', 0), 1),
            'fats_per_100g': round(nutrients.get('FAT', 0), 1),
            'fiber_per_100g': round(nutrients.get('FIBTG', 0), 1),
            'sugar_per_100g': round(nutrients.get('SUGAR', 0), 1),
            'sodium_per_100g': round(nutrients.get('NA', 0), 1),
            'source': 'Edamam Food Database API'
        }
        
        return result
        
    except requests.exceptions.RequestException as e:
        return {
            'error': f'API request failed: {str(e)}'
        }
    except (KeyError, ValueError, json.JSONDecodeError) as e:
        return {
            'error': f'Error parsing API response: {str(e)}'
        }

def get_dish_image(dish_name):
    """
    Get an image URL for a dish
    
    Args:
        dish_name (str): The name of the dish
        
    Returns:
        str: URL to an image of the dish or None if not found
    """
    # This could be implemented with another API like Unsplash, Pexels, or Google Custom Search
    # For now, we'll return None
    return None