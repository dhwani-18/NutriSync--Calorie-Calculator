# food_tracker/management/commands/add_sample_foods.py

from django.core.management.base import BaseCommand
from food_tracker.models import Food

class Command(BaseCommand):
    help = 'Add sample foods to the database'

    def handle(self, *args, **options):
        sample_foods = [
            {
                'name': 'Basmati Rice',
                'category': 'Grains',
                'calories_per_100g': 365,
                'protein_per_100g': 7.1,
                'carbs_per_100g': 78.2,
                'fats_per_100g': 0.9,
                'fiber_per_100g': 1.3,
            },
            {
                'name': 'Chicken Breast',
                'category': 'Meat',
                'calories_per_100g': 165,
                'protein_per_100g': 31.0,
                'carbs_per_100g': 0.0,
                'fats_per_100g': 3.6,
                'fiber_per_100g': 0.0,
            },
            {
                'name': 'Banana',
                'category': 'Fruits',
                'calories_per_100g': 89,
                'protein_per_100g': 1.1,
                'carbs_per_100g': 22.8,
                'fats_per_100g': 0.3,
                'fiber_per_100g': 2.6,
                'sugar_per_100g': 12.2,
            },
            {
                'name': 'Whole Milk',
                'category': 'Dairy',
                'calories_per_100g': 61,
                'protein_per_100g': 3.2,
                'carbs_per_100g': 4.8,
                'fats_per_100g': 3.3,
                'fiber_per_100g': 0.0,
                'sugar_per_100g': 5.1,
            },
            {
                'name': 'Brown Bread',
                'category': 'Grains',
                'calories_per_100g': 247,
                'protein_per_100g': 13.0,
                'carbs_per_100g': 41.0,
                'fats_per_100g': 4.2,
                'fiber_per_100g': 6.0,
            },
            {
                'name': 'Apple',
                'category': 'Fruits',
                'calories_per_100g': 52,
                'protein_per_100g': 0.3,
                'carbs_per_100g': 13.8,
                'fats_per_100g': 0.2,
                'fiber_per_100g': 2.4,
                'sugar_per_100g': 10.4,
            },
            {
                'name': 'Paneer',
                'category': 'Dairy',
                'calories_per_100g': 265,
                'protein_per_100g': 18.3,
                'carbs_per_100g': 1.2,
                'fats_per_100g': 20.8,
                'fiber_per_100g': 0.0,
            },
            {
                'name': 'Dal (Toor Dal)',
                'category': 'Legumes',
                'calories_per_100g': 335,
                'protein_per_100g': 22.3,
                'carbs_per_100g': 57.6,
                'fats_per_100g': 1.7,
                'fiber_per_100g': 9.7,
            },
            {
                'name': 'Chapati',
                'category': 'Grains',
                'calories_per_100g': 297,
                'protein_per_100g': 11.8,
                'carbs_per_100g': 58.6,
                'fats_per_100g': 4.4,
                'fiber_per_100g': 11.2,
            },
            {
                'name': 'Spinach',
                'category': 'Vegetables',
                'calories_per_100g': 23,
                'protein_per_100g': 2.9,
                'carbs_per_100g': 3.6,
                'fats_per_100g': 0.4,
                'fiber_per_100g': 2.2,
            },
            {
                'name': 'Yogurt',
                'category': 'Dairy',
                'calories_per_100g': 59,
                'protein_per_100g': 10.0,
                'carbs_per_100g': 3.6,
                'fats_per_100g': 0.4,
                'fiber_per_100g': 0.0,
                'sugar_per_100g': 3.6,
            },
            {
                'name': 'Almonds',
                'category': 'Nuts',
                'calories_per_100g': 579,
                'protein_per_100g': 21.2,
                'carbs_per_100g': 21.6,
                'fats_per_100g': 49.9,
                'fiber_per_100g': 12.5,
            },
            {
                'name': 'Egg',
                'category': 'Protein',
                'calories_per_100g': 155,
                'protein_per_100g': 13.0,
                'carbs_per_100g': 1.1,
                'fats_per_100g': 11.0,
                'fiber_per_100g': 0.0,
            },
            {
                'name': 'Potato',
                'category': 'Vegetables',
                'calories_per_100g': 77,
                'protein_per_100g': 2.0,
                'carbs_per_100g': 17.0,
                'fats_per_100g': 0.1,
                'fiber_per_100g': 2.2,
            },
            {
                'name': 'Tomato',
                'category': 'Vegetables',
                'calories_per_100g': 18,
                'protein_per_100g': 0.9,
                'carbs_per_100g': 3.9,
                'fats_per_100g': 0.2,
                'fiber_per_100g': 1.2,
                'sugar_per_100g': 2.6,
            },
        ]

        created_count = 0
        for food_data in sample_foods:
            food, created = Food.objects.get_or_create(
                name=food_data['name'],
                defaults=food_data
            )
            if created:
                created_count += 1
                self.stdout.write(
                    self.style.SUCCESS(f'Successfully created food: {food.name}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Food already exists: {food.name}')
                )

        self.stdout.write(
            self.style.SUCCESS(f'\nCreated {created_count} new foods out of {len(sample_foods)} total foods.')
        )