import requests
from bs4 import BeautifulSoup
import sys

# Start a session
session = requests.Session()

# Get the login page to get the CSRF token
login_url = 'http://127.0.0.1:8000/login/'
login_response = session.get(login_url)
login_soup = BeautifulSoup(login_response.text, 'html.parser')

# Extract the CSRF token
csrf_token = login_soup.find('input', {'name': 'csrfmiddlewaretoken'})['value']

# Login data
login_data = {
    'csrfmiddlewaretoken': csrf_token,
    'username': 'admin',  # Use the superuser we created
    'password': 'admin123',  # The password we set for the superuser
}

print(f'CSRF Token: {csrf_token}')
print(f'Login data: {login_data}')

# Submit the login form
login_post_response = session.post(login_url, data=login_data, headers={
    'Referer': login_url
})

# Check if login was successful
if login_post_response.url.endswith('/dashboard/'):
    print('Login successful!')
    
    # Now try to access the food entries page
    food_entries_url = 'http://127.0.0.1:8000/entries/'
    food_entries_response = session.get(food_entries_url)
    
    # Print the status code and URL
    print(f'Food entries page status code: {food_entries_response.status_code}')
    print(f'Food entries page URL: {food_entries_response.url}')
    
    # Check if we got the food entries page or were redirected
    if food_entries_response.url.endswith('/entries/'):
        print('Successfully accessed food entries page!')
        
        # Check for template errors in the response
        if 'TemplateSyntaxError' in food_entries_response.text:
            print('Template syntax error found in the response!')
            # Extract the error message
            soup = BeautifulSoup(food_entries_response.text, 'html.parser')
            error_text = soup.find('pre').text if soup.find('pre') else 'Error details not found'
            print(f'Error: {error_text}')
        else:
            print('No template errors found!')
    else:
        print(f'Redirected to: {food_entries_response.url}')
else:
    print(f'Login failed! Redirected to: {login_post_response.url}')
    sys.exit(1)