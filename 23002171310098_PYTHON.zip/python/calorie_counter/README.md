# Calorie Counter Django Application

A comprehensive Django web application for tracking calories and nutritional information from food entries and dish names.

## Features

- **User Authentication**: Register, login, and manage user profiles with personalized calorie goals
- **Food Database**: Comprehensive database of foods with nutritional information
- **Food Entry Tracking**: Log food entries with meal types, quantities, and dates
- **Dashboard**: Visual representation of daily calorie intake and macronutrient breakdown
- **Analytics**: Track nutrition trends over time with detailed statistics
- **Dish Recognition**: Identify nutritional information from dish names using the Edamam API

## Installation

1. Clone the repository
2. Create a virtual environment:
   ```
   python -m venv venv
   venv\Scripts\activate  # Windows
   source venv/bin/activate  # Linux/Mac
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Apply migrations:
   ```
   python manage.py migrate
   ```
5. Create a superuser:
   ```
   python manage.py createsuperuser
   ```
6. Load sample food data (optional):
   ```
   python manage.py add_sample_foods
   ```

## API Configuration for Dish Recognition

To use the dish recognition feature, you need to sign up for an API key from Edamam:

1. Visit [Edamam Developer Portal](https://developer.edamam.com/food-database-api) and sign up for the Food Database API
2. Get your Application ID and Application Key
3. Set these as environment variables:
   ```
   # Windows
   set EDAMAM_APP_ID=your_app_id
   set EDAMAM_APP_KEY=your_app_key
   
   # Linux/Mac
   export EDAMAM_APP_ID=your_app_id
   export EDAMAM_APP_KEY=your_app_key
   ```

Alternatively, you can add these to your `.env` file or directly in the `dish_recognition.py` file (not recommended for production).

## Running the Application

```
python manage.py runserver
```

Visit http://127.0.0.1:8000/ in your browser.

## Usage

### Dish Recognition

1. Log in to your account
2. Navigate to "Recognize Dish" in the navigation menu
3. Enter a dish name (e.g., "Chicken Parmesan", "Greek Salad")
4. View the nutritional information for the dish
5. Optionally add the dish to your food database or directly as a food entry

### Food Tracking

1. Add foods to your database or search for existing foods
2. Create food entries with quantities and meal types
3. View your daily progress on the dashboard
4. Analyze your nutrition trends in the Analytics section

## Project Structure

- `calorie_counter/` - Main project directory
  - `settings.py` - Project settings
  - `urls.py` - Main URL configuration
- `food_tracker/` - Main application
  - `models.py` - Database models for Food, FoodEntry, UserProfile
  - `views.py` - View functions for all features
  - `urls.py` - URL patterns for the application
  - `forms.py` - Forms for user input
  - `dish_recognition.py` - API integration for dish recognition
  - `templates/` - HTML templates
  - `management/commands/` - Custom management commands

## Technologies Used

- Django 4.x
- Bootstrap 5
- SQLite (default database)
- Edamam Food Database API
- Chart.js (for analytics visualizations)

## License

MIT